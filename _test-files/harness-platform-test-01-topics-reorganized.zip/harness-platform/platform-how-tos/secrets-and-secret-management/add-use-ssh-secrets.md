---
title: Add SSH Keys
description: This document explains how to add and use SSH secrets.
tags: 
   - helpDocs
# sidebar_position: 2
helpdocs_topic_id: xmp9j0dk8b
helpdocs_category_id: 48wnu4u0tj
helpdocs_is_private: false
helpdocs_is_published: true
---

You can add SSH keys for use in connecting to remote servers, such as an AWS EC2 instance.

In this topic:

* [Before You Begin](#before_you_begin)
* [Configure SSH Connectivity](https://ngdocs.harness.io/article/xmp9j0dk8b-add-use-ssh-secrets#configure_ssh_connectivity)
* [Notes](https://ngdocs.harness.io/article/xmp9j0dk8b-add-use-ssh-secrets#notes)

### Before You Begin

* [Learn Harness' Key Concepts](/article/hv2758ro4e-learn-harness-key-concepts)
* [Harness Secret Manager Overview](/article/hngrlb7rd6-harness-secret-manager-overview)
* [Add a Secret Manager](/article/bo4qbrcggv-add-secrets-manager)
* [Add Text Secrets](/article/osfw70e59c-add-use-text-secrets)
* [Add File Secrets](/article/77tfo7vtea-add-file-secrets)

### Add SSH Credential

To add an SSH key that can be referenced in Harness entities, do the following:

1. Select your **Account**/**Organization**/**Project**.
2. In **ACCOUNT SETUP**/**ORG SETUP**/**PROJECT SETUP**, Click **Secrets**.
3. Click **New Secret** and select **SSH Credential.**

![](https://files.helpdocs.io/i5nl071jo5/articles/xmp9j0dk8b/1619288020327/image.png)The **SSH Credential** settings appear.

![](https://files.helpdocs.io/i5nl071jo5/articles/xmp9j0dk8b/1627898639058/screenshot-2021-08-02-at-3-33-06-pm.png)1. Enter a **Name** for the SSH Credential and click **Continue**.
2. Under **Select an Auth Scheme**, select one of the following:
	1. **SSH Key:** add SSH keys for Harness to use when connecting to remote servers.
	2. **Kerberos:** SSH into a target host via the Kerberos protocol.
3. In **User Name**, provide the username for the user account on the remote server. For example, if you want to SSH into an AWS EC2 instance, the username would be **ec2-user**.
4. In **Select or create a SSH Key**, click **Create or Select a Secret**.
5. You can do one of the following:
	1. Click **Create a new secret**. You can create an [Encrypted File Secret](/article/77tfo7vtea-add-file-secrets) or an [Encrypted Text Secret](/article/osfw70e59c-add-use-text-secrets).
	2. Click **Select an existing secret.** You can add an existing [Encrypted File Secret](/article/77tfo7vtea-add-file-secrets) or an [Encrypted Text Secret](/article/osfw70e59c-add-use-text-secrets) present at your Project, Account or Organization level.

If you are editing an existing SSH Key File, you will not be able to edit the existing inline key that you have entered earlier. Instead, you should select an existing file or create a new Encrypted SSH key file.1. In **Select Encrypted Passphrase**, add the SSH key [passphrase](https://www.ssh.com/ssh/passphrase) if one is required. It is **not** required by default for AWS or many other platforms. Make sure you use a Harness Encrypted Text secret to save the passphrase and refer to it here. Either select an existing secret from the drop-down list or create a new one by clicking  **Create or Select a Secret**. For more information on creating an Encrypted Text Secret, see [Add Text Secrets](/article/osfw70e59c-add-use-text-secrets).
2. In **SSH Port**, leave the default **22** or enter a different port if needed.
3. Click **Save and Continue**.
4. In **Host Name**, enter the hostname of the remote server you want to SSH into. For example, if it is an AWS EC2 instance, it will be something like, `ec2-76-939-110-125.us-west-1.compute.amazonaws.com`.
5. Click **Test Connection**. If the test is unsuccessful, you might see an error stating that no Harness Delegate could reach the host, or that a credential is invalid. Make sure that your settings are correct and that a Harness Delegate is able to connect to the server.
6. When a test is successful, click **Submit**.

### Notes

You can convert your OpenSSH key to a PEM format with:

`ssh-keygen -p -m PEM -f your_private_key`

This will convert your existing file headers from:

`-----BEGIN OPENSSH PRIVATE KEY-----`

to

`-----BEGIN RSA PRIVATE KEY-----`


---
title: Add and Manage Resource Groups
description: This document shows steps to create and manage resource groups and assign them to user groups.
tags: 
   - helpDocs
   - RBAC
   - AccessManagement
# sidebar_position: 2
helpdocs_topic_id: yp4xj36xro
helpdocs_category_id: w4rzhnf27d
helpdocs_is_private: false
helpdocs_is_published: true
---

A Resource Group is a set of Harness resources that the permission applies to. Permissions given to a user or user group as part of a Role, apply to the set of resources that are part of the Resource Group.

This topic will explain the steps to create and manage Resource Groups within Harness System.

### Before You Begin

* [Learn Harness' Key Concepts](https://ngdocs.harness.io/article/hv2758ro4e-learn-harness-key-concepts)
* [Access Management (RBAC) Overview](/article/vz5cq0nfg2-rbac-in-harness)
* Make sure you have **Create/Edit/Delete** Permissions for Resource Groups.

### Visual Summary

Here is a quick overview of Resource Groups at various scopes:

* **Account Only** - To include all the resources within the scope of the Account. This does not include resources within the scope of Org or Project.
* **All (including all Organizations and Projects)** - To include all the resources within the scope of the Account, as well as those within the scope of the Orgs and Projects in this Account.
* **Specified Organizations (and their Projects)** - To include all the resources within the scope of specific Organizations and their Projects.

![](https://files.helpdocs.io/i5nl071jo5/articles/yp4xj36xro/1653287317177/screenshot-2022-05-23-at-11-25-08-am.png)### Review: Resource Groups and Scopes

A Resource Group can contain any of the following:

* All or selected resources from the list of resources in the Resource Group's scope - For example, a Resource Group RG1 created within Account Acc1 can contain all or selected resources created within the same Account Acc1.
* All or selected resources in the scope in which it is defined. For example, all Account level resources, all Account Level Secret Managers, all Connectors in Org A.
* All or specific resources for the entire account - For example, a Resource Group RG1 within Account Acc1 can contain all or selected resources created within Acc1, Organizations within Acc1, Projects within Organizations in Acc1.![](https://files.helpdocs.io/i5nl071jo5/articles/yp4xj36xro/1643806552171/screenshot-2022-02-02-at-6-25-13-pm.png)

Harness includes the following built-in Resource Groups at the Account, Org, and Project scope:



|  |  |  |
| --- | --- | --- |
| Scope | Resource Group | Description |
| Account | **All Resources Including Child Scopes** | Includes all the resources within the scope of the Account, as well as those within the scope of the Orgs and Projects in this Account. |
| Account | **All Account Level Resources** | Includes all the resources within the scope of the Account. This does not include resources within the scope of Org or Project. |
| Org | **All Resources Including Child Scopes** | Includes all the resources within the scope of the Org, as well as those within the scope of all the Projects created within this Org. |
| Org | **All Organization Level Resources** | Includes all the resources within the scope of the Org. This does not include resources within the scope of Projects. |
| Project | **All Project Level Resources** | Includes all the resources within the scope of the Project. |

### Step 1: Add a New Resource Group

Select your **Project/Org/****Account**, and click **Access Control**.

Click **Resource Groups** and then click **New Resource** **Group****.** The New Resource Group settings appear.

Enter a **Name** for your **Resource Group**.

Enter **Description** and **Tags** for your **Resource Group**.

![](https://files.helpdocs.io/i5nl071jo5/articles/yp4xj36xro/1652951116293/screenshot-2022-05-19-at-2-34-42-pm.png)Click **Save**.

### Step 2: Select a Resource Scope

You must select the scope of the resources that must be included in your new Resource Group after it has been saved.

![](https://files.helpdocs.io/i5nl071jo5/articles/yp4xj36xro/1652951993021/screenshot-2022-05-19-at-2-49-26-pm.png)You can select one of the following in Resource Group:

* **Account Only**
* **All (including all Organizations and Projects)**
* **Specified Organizations (and their Projects)**![](https://files.helpdocs.io/i5nl071jo5/articles/yp4xj36xro/1652954036367/screenshot-2022-05-19-at-3-21-07-pm.png)For each Organization you select, you can further select **All** or **Specified** Projects within this Organization to include the resources accordingly.![](https://files.helpdocs.io/i5nl071jo5/articles/yp4xj36xro/1652955546918/screenshot-2022-05-19-at-3-47-32-pm.png)

Click **Apply**.

### Step 3: Select Resources

After you have selected Resource Scope, you must select the resources that you want to include in this Resource group.

You can either Select **All** or **Specified** resources.

![](https://files.helpdocs.io/i5nl071jo5/articles/yp4xj36xro/1652955964761/screenshot-2022-05-19-at-3-55-31-pm.png)Click **Save**.

Go back to Resource Groups. Your Resource Group is now listed here.

![](https://files.helpdocs.io/i5nl071jo5/articles/yp4xj36xro/1652956148212/screenshot-2022-05-19-at-3-58-02-pm.png)### Step: Delete A Resource Group

Click the **Resource Groups** tab under **Access Control.**

Click **Delete** on the top right corner to remove a Resource Group.

![](https://files.helpdocs.io/i5nl071jo5/articles/yp4xj36xro/1621233316056/screenshot-2021-05-17-at-12-02-33-pm.png)### Step: Manage Resource Group

Click the **Resource Groups** tab under **Access Control.**

Click the Resource Group you want to edit. The Resource Group details page appears.

You can add/remove resources from this page.

Click **Apply Changes**.

### Next Steps

* [Add and Manage Users](/article/hyoe7qcaz6-add-users)
* [Add and Manage User Groups](/article/dfwuvmy33m-add-user-groups)
* [Add and Manage Roles](/article/tsons9mu0v-add-roles)
* [Permissions Reference](/article/yaornnqh0z-permissions-reference)

